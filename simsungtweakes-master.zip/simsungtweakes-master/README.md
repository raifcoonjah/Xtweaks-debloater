<b>Simsung Tweaks</b> by mraif13

All files needed are here.
This will not trip knox.
